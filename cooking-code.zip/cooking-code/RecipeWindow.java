import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.HashSet;
import java.util.Set;
//class for window that shows names of the recipes
public class RecipeWindow extends JFrame
{
    private static Set<RecipeWindow> instances = new HashSet<>();
    private static final String DUPLICATE_WINDOW_MESSAGE = "This window is already open.";
    private static final int WINDOW_WIDTH = 500;
    private static final int WINDOW_HEIGHT = 600;
    private static final int BUTTON_HEIGHT = 250;
    private static final int TOP_BOTTOM_SPACING = 30;

    private static RecipeWindow instance;
    private Map<String, Map<String, ImageIcon>> recipes;

    private RecipeWindow(String category) 
    {
        setTitle("Recipes - " + category);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
        setRandomLocation();
        setResizable(false);

        JPanel contentPane = new JPanel(new BorderLayout());
        setContentPane(contentPane);

        // Create top and bottom gaps
        JPanel topSpacingPanel = new JPanel();
        topSpacingPanel.setPreferredSize(new Dimension(WINDOW_WIDTH, TOP_BOTTOM_SPACING));
        JPanel bottomSpacingPanel = new JPanel();
        bottomSpacingPanel.setPreferredSize(new Dimension(WINDOW_WIDTH, TOP_BOTTOM_SPACING));

        // Create panel with buttons
        JPanel centerPanel = new JPanel(new GridLayout(0, 1, 10, 10));

        recipes = loadRecipes(category);

        //set up for the buttons 
        for (Map.Entry<String, ImageIcon> entry : recipes.get(category).entrySet()) 
        {
          String recipeName = entry.getKey();
          ImageIcon recipeImage = scaleImage(entry.getValue(), BUTTON_HEIGHT - 50);

          JButton button = new JButton(recipeName, recipeImage);
          button.setVerticalTextPosition(SwingConstants.BOTTOM);
          button.setHorizontalTextPosition(SwingConstants.CENTER);
          button.setPreferredSize(new Dimension(WINDOW_WIDTH - 20, BUTTON_HEIGHT));
          button.setOpaque(false);
          button.setContentAreaFilled(false);
          button.setBorderPainted(false);
          button.setFont(new Font("Serif", Font.BOLD, 16));

          button.addActionListener(new RecipeButtonListener(recipeName));

          centerPanel.add(button);
        }

        contentPane.add(topSpacingPanel, BorderLayout.NORTH);
        contentPane.add(centerPanel, BorderLayout.CENTER);
        contentPane.add(bottomSpacingPanel, BorderLayout.SOUTH);

        pack();
        setVisible(true);
        instances.add(this);
    }
    
    public static void showWindow(String category) 
    {
        // Remove disposed instances from the instances set
        instances.removeIf(window -> window.isDisposed());

        // Check if a window with the same title already exists
        for (RecipeWindow window : instances) 
        {
            if (window.getTitle().equals("Recipes - " + category)) 
            {
                JOptionPane.showMessageDialog(null, DUPLICATE_WINDOW_MESSAGE, "Warning", JOptionPane.WARNING_MESSAGE);
                return;
            }
        }

        //creating a new window and closing all previous if user wants
        if (instances.isEmpty()) 
        {
            instances.add(new RecipeWindow(category));
        } 
        else 
        {
            int option = JOptionPane.showConfirmDialog(null, "Do you want to close all previous windows?", "Confirm", JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION) 
            {
                for (RecipeWindow window : instances) 
                {
                    window.dispose();
                }
                instances.clear();
                instances.add(new RecipeWindow(category));
            } 
            else if (option == JOptionPane.NO_OPTION) 
            {
               instances.add(new RecipeWindow(category));
            }
        }
    }

    //setting random location for the windows (to use random numbers and don't get one window on top of the other)
    private void setRandomLocation() 
    {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int screenWidth = (int) screenSize.getWidth();
        int screenHeight = (int) screenSize.getHeight();

        Random random = new Random();
        int x = random.nextInt(screenWidth - WINDOW_WIDTH);
        int y = random.nextInt(screenHeight - WINDOW_HEIGHT);

        setLocation(x, y);
    }

    private ImageIcon scaleImage(ImageIcon icon, int height) 
    {
        Image image = icon.getImage().getScaledInstance(-1, height, Image.SCALE_SMOOTH);
        return new ImageIcon(image);
    }

    //adding names of the recipes as buttons
    private Map<String, Map<String, ImageIcon>> loadRecipes(String category) 
    {
        Map<String, Map<String, ImageIcon>> recipes = new HashMap<>();

        Map<String, ImageIcon> dessertsRecipes = new HashMap<>();
        dessertsRecipes.put("Charlotte", new ImageIcon("charlotte.jpg"));
        dessertsRecipes.put("Cottage cheese pancakes", new ImageIcon("cottage cheese pancakes.jpg"));

        Map<String, ImageIcon> dinnerRecipes = new HashMap<>();
        dinnerRecipes.put("Teriyaki chicken", new ImageIcon("teriyaki chicken.jpg"));
        dinnerRecipes.put("Plov", new ImageIcon("plov.jpg"));

        Map<String, ImageIcon> lunchRecipes = new HashMap<>();
        lunchRecipes.put("Glass noodles salad", new ImageIcon("glass noodles salad.jpg"));
        lunchRecipes.put("Sushi burger", new ImageIcon("sushi burger.png"));
        
        Map<String, ImageIcon> breakfastRecipes = new HashMap<>();
        breakfastRecipes.put("Oatmeal pancake", new ImageIcon("oatmeal pancake.png"));
        breakfastRecipes.put("Crepes", new ImageIcon("crepes.jpg"));
        
        Map<String, ImageIcon> snacksRecipes = new HashMap<>();
        snacksRecipes.put("Salty puffs", new ImageIcon("salty puffs.jpg"));
        snacksRecipes.put("Glazed curds", new ImageIcon("glazed curds.jpg"));
        
        Map<String, ImageIcon> quickRecipes = new HashMap<>();
        quickRecipes.put("Chia pudding", new ImageIcon("chia pudding.jpg"));
        quickRecipes.put("Baked apples", new ImageIcon("baked apples.jpg"));
        
        Map<String, ImageIcon> lowRecipes = new HashMap<>();
        lowRecipes.put("Protein cupcakes", new ImageIcon("protein cupcakes.jpg"));
        lowRecipes.put("Lettuce burger", new ImageIcon("lettuce leaf burger.png"));
        
        recipes.put("Desserts", dessertsRecipes);
        recipes.put("Dinner", dinnerRecipes);
        recipes.put("Lunch", lunchRecipes);
        recipes.put("Breakfast", breakfastRecipes);
        recipes.put("Low", lowRecipes);
        recipes.put("Quick", quickRecipes);
        recipes.put("Snacks", snacksRecipes);

        return recipes;
    } 
    //checking if the are any disposed instances
    private boolean isDisposed = false;

    public boolean isDisposed() 
    {
        return isDisposed;
    }

    @Override
    public void dispose() 
    {
       super.dispose();
       isDisposed = true;
    }
} 