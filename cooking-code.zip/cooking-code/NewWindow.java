import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

class NewWindow extends JFrame 
{
    private JScrollPane scrollPane;
    private JPanel imagePanel;
    private JTextField textField;
    private JButton iconButton;
    private JPanel buttonsPanel;
    private JWindow buttonWindow;

    private static final String DEFAULT_TEXT = "find your recipe...";

    private ImageIcon scaleImageIcon(ImageIcon icon, int width, int height) 
    {
        Image image = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
        return new ImageIcon(image);
    }

    public NewWindow(Dimension size) 
    {
        setTitle("The Cooking Code");
        setSize(size);
        setMinimumSize(getSize()); // Prevent window resizing
        setLocationRelativeTo(null);
        setResizable(false); // Disable window resizing
        setLayout(new BorderLayout());

        // top panel
        JPanel topPanel = new JPanel(new GridBagLayout());

        // user icon button
        ImageIcon buttonIcon = new ImageIcon(getClass().getResource("icon1.png"));
        Image image = buttonIcon.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);
        buttonIcon = new ImageIcon(image);
        iconButton = new JButton(buttonIcon);
        iconButton.setPreferredSize(new Dimension(40, 40));
        iconButton.setOpaque(false);
        iconButton.setContentAreaFilled(false);
        iconButton.setBorderPainted(false); // Remove the button border
        iconButton.addActionListener(new IconButtonClickListener());

        // user icons panel (click circle-button near textfield to see)
        buttonsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        buttonsPanel.setOpaque(false);
        for (int i = 1; i <= 5; i++) 
        {
            ImageIcon buttonIconSmall = new ImageIcon(getClass().getResource("icon" + i + ".png"));
            Image imageSmall = buttonIconSmall.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);
            buttonIconSmall = new ImageIcon(imageSmall);
            JButton button = new JButton(buttonIconSmall);
            button.setPreferredSize(new Dimension(40, 40));
            button.setOpaque(false);
            button.setContentAreaFilled(false); 
            button.setBorderPainted(false); // Remove the button border
            //button.addActionListener(new ButtonClickListener(button));
            
            button.addActionListener(e -> {
                iconButton.setIcon(button.getIcon());
    
                if (buttonWindow != null)
                {
                    buttonWindow.dispose();
                }});
            
            buttonsPanel.add(button);
        }

        // Adding components to the top panel
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(0, 0, 0, 5); // 5 pix of right
        topPanel.add(iconButton, gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.insets = new Insets(0, 0, 0, 0);
        topPanel.add(buttonsPanel, gbc);
        buttonsPanel.setVisible(false);

        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.insets = new Insets(0, 0, 0, 5); // 5 pix of right
        textField = new JTextField(65);
        textField.setText(DEFAULT_TEXT);
        textField.setForeground(Color.GRAY);
        //default text for textfield
        textField.addFocusListener(new FocusListener() 
        {
            @Override
            public void focusGained(FocusEvent e) {
                if (textField.getText().equals(DEFAULT_TEXT)) 
                {
                    textField.setText("");
                    textField.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent e) 
            {
                if (textField.getText().isEmpty()) 
                {
                    textField.setText(DEFAULT_TEXT);
                    textField.setForeground(Color.GRAY);
                }
            }
        });
        topPanel.add(textField, gbc);

        add(topPanel, BorderLayout.NORTH);

        //background image
        ImageIcon backgroundImage = new ImageIcon(getClass().getResource("white background3.png"));

        // panel that holds background image
        imagePanel = new JPanel() 
        {
            @Override
            protected void paintComponent(Graphics g) 
            {
                super.paintComponent(g);
                if (backgroundImage != null) 
                {
                    int imageWidth = backgroundImage.getIconWidth();
                    int imageHeight = backgroundImage.getIconHeight();
                    int windowWidth = getWidth();
                    int windowHeight = getHeight();
                    int x = 0;
                    int y = 0;
                    while (y < windowHeight) 
                    {
                        x = 0;
                        while (x < windowWidth) 
                        {
                            backgroundImage.paintIcon(this, g, x, y);
                            x += imageWidth;
                        }
                        y += imageHeight;
                    }
                }
            }

            @Override
            public Dimension getPreferredSize() 
            {
                if (backgroundImage != null) 
                {
                    return new Dimension(backgroundImage.getIconWidth(), backgroundImage.getIconHeight());
                }
                return super.getPreferredSize();
            }
        };

        //JPanel to hold the menu buttons
        JPanel westPanel = new JPanel();
        westPanel.setLayout(new BoxLayout(westPanel, BoxLayout.Y_AXIS));
        westPanel.setOpaque(false);
       
        //Layout setup
        // First row
        JPanel firstRow = new JPanel(new FlowLayout(FlowLayout.LEADING, 20, 0));
        firstRow.setOpaque(false);
        ImageIcon dessertsIcon = new ImageIcon(getClass().getResource("desserts.png"));
        dessertsIcon = scaleImageIcon(dessertsIcon, 400, 120);
        JButton dessertsButton = new JButton(dessertsIcon);
        dessertsButton.setPreferredSize(new Dimension(400, 120));
        dessertsButton.setOpaque(false);
        dessertsButton.setContentAreaFilled(false);
        dessertsButton.setBorderPainted(false);
        firstRow.add(dessertsButton);

        ImageIcon snacksIcon = new ImageIcon(getClass().getResource("snacks.png"));
        snacksIcon = scaleImageIcon(snacksIcon, 280, 180);
        JButton snacksButton = new JButton(snacksIcon);
        snacksButton.setPreferredSize(new Dimension(280, 180));
        snacksButton.setOpaque(false);
        snacksButton.setContentAreaFilled(false);
        snacksButton.setBorderPainted(false);
        firstRow.add(snacksButton);

        // Second row
        JPanel secondRow = new JPanel(new FlowLayout(FlowLayout.LEADING, 30, 20));
        secondRow.setOpaque(false);
        ImageIcon dinnerIcon = new ImageIcon(getClass().getResource("dinner.png"));
        dinnerIcon = scaleImageIcon(dinnerIcon, 190, 350);
        JButton dinnerButton = new JButton(dinnerIcon);
        dinnerButton.setPreferredSize(new Dimension(190, 350));
        dinnerButton.setOpaque(false);
        dinnerButton.setContentAreaFilled(false);
        dinnerButton.setBorderPainted(false);
        secondRow.add(dinnerButton);

        ImageIcon lowIcon = new ImageIcon(getClass().getResource("low.png"));
        lowIcon = scaleImageIcon(lowIcon, 200, 250);
        JButton lowButton = new JButton(lowIcon);
        lowButton.setPreferredSize(new Dimension(200, 250));
        lowButton.setOpaque(false);
        lowButton.setContentAreaFilled(false);
        lowButton.setBorderPainted(false);
        secondRow.add(lowButton);

        ImageIcon quickIcon = new ImageIcon(getClass().getResource("quick.png"));
        quickIcon = scaleImageIcon(quickIcon, 180, 220);
        JButton quickButton = new JButton(quickIcon);
        quickButton.setPreferredSize(new Dimension(180, 220));
        quickButton.setOpaque(false);
        quickButton.setContentAreaFilled(false);
        quickButton.setBorderPainted(false);
        secondRow.add(quickButton);

        // Third row
        JPanel thirdRow = new JPanel(new FlowLayout(FlowLayout.LEADING, 20, 0));
        thirdRow.setOpaque(false);
        ImageIcon breakfastIcon = new ImageIcon(getClass().getResource("breakfast.png"));
        breakfastIcon = scaleImageIcon(breakfastIcon, 700, 120);
        JButton breakfastButton = new JButton(breakfastIcon);
        breakfastButton.setPreferredSize(new Dimension(700, 120));
        breakfastButton.setOpaque(false);
        breakfastButton.setContentAreaFilled(false);
        breakfastButton.setBorderPainted(false);
        thirdRow.add(breakfastButton);

        // Fourth row
        JPanel fourthRow = new JPanel(new FlowLayout(FlowLayout.LEADING, 25, 20));
        fourthRow.setOpaque(false);
        JPanel GandLpanel = new JPanel(new FlowLayout(FlowLayout.LEADING, 15, 0));
        GandLpanel.setOpaque(false);
        ImageIcon glutenIcon = new ImageIcon(getClass().getResource("glutenfreemeals.png"));
        glutenIcon = scaleImageIcon(glutenIcon, 180, 180);
        JButton glutenButton = new JButton(glutenIcon);
        glutenButton.setPreferredSize(new Dimension(180, 180));
        glutenButton.setOpaque(false);
        glutenButton.setContentAreaFilled(false);
        glutenButton.setBorderPainted(false);
        GandLpanel.add(glutenButton);

        ImageIcon lactoseIcon = new ImageIcon(getClass().getResource("lactosefreemeals.png"));
        lactoseIcon = scaleImageIcon(lactoseIcon, 180, 180);
        JButton lactoseButton = new JButton(lactoseIcon);
        lactoseButton.setPreferredSize(new Dimension(180, 180));
        lactoseButton.setOpaque(false);
        lactoseButton.setContentAreaFilled(false);
        lactoseButton.setBorderPainted(false);
        GandLpanel.add(lactoseButton);
        
        fourthRow.add(GandLpanel);

        ImageIcon lunchIcon = new ImageIcon(getClass().getResource("lunch.png"));
        lunchIcon = scaleImageIcon(lunchIcon, 250, 290);
        JButton lunchButton = new JButton(lunchIcon);
        lunchButton.setPreferredSize(new Dimension(250, 290));
        lunchButton.setOpaque(false);
        lunchButton.setContentAreaFilled(false);
        lunchButton.setBorderPainted(false);
        fourthRow.add(lunchButton);

        westPanel.add(firstRow);
        westPanel.add(secondRow);
        westPanel.add(thirdRow);
        westPanel.add(fourthRow);
        
        imagePanel.add(westPanel);

        scrollPane = new JScrollPane(imagePanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);        // Add the scroll pane to the content pane
        add(scrollPane, BorderLayout.CENTER);

        dessertsButton.addActionListener(new MenuButtonListener("Desserts"));
        snacksButton.addActionListener(new MenuButtonListener("Snacks"));
        dinnerButton.addActionListener(new MenuButtonListener("Dinner"));
        lowButton.addActionListener(new MenuButtonListener("Low"));
        quickButton.addActionListener(new MenuButtonListener("Quick"));
        breakfastButton.addActionListener(new MenuButtonListener("Breakfast"));
        glutenButton.addActionListener(new MenuButtonListener("Gluten-Free"));
        lactoseButton.addActionListener(new MenuButtonListener("Lactose-Free"));
        lunchButton.addActionListener(new MenuButtonListener("Lunch"));
        
        setVisible(true);
    } 
    //I did not separate those classes into the different codes, because they all belong to the same window
    //for buttons in icon panel
    private class IconButtonClickListener implements ActionListener
    {
        
       @Override
       public void actionPerformed(ActionEvent e)
       {
          //window with image buttons to choose an user icon
          if (buttonWindow == null) 
          {
            buttonWindow = new JWindow(NewWindow.this);
            buttonWindow.setLocation(getX() + iconButton.getX(), getY() + iconButton.getY() + iconButton.getHeight());
            buttonWindow.setSize(200, 85); 
            
            buttonWindow.addWindowFocusListener(new WindowAdapter() 
            {
                @Override
                public void windowLostFocus(WindowEvent e) 
                {
                    buttonWindow.dispose(); // Dispose the window when it loses focus
                }
            });

            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 0));
            buttonPanel.setBorder(new LineBorder(Color.BLACK, 1)); // black border

            // Adding buttons to the buttonPanel
            for (Component component : buttonsPanel.getComponents()) 
            {
                JButton button = (JButton) component;
                buttonPanel.add(button);
            }

            buttonWindow.add(buttonPanel);
          }

        buttonWindow.setVisible(true);
       }
    }
    
    //if one of the buttons(dinner, desserts,...) clicked opens a window with names of recipes(recipeWindow)
    private class MenuButtonListener implements ActionListener 
    {
        private final String category;
    
        public MenuButtonListener(String category) 
        {
            this.category = category;
        }
    
        @Override
        public void actionPerformed(ActionEvent e) 
        {
            RecipeWindow.showWindow(category);
        }
    
    } 
    
    public static void main(String[] args) 
    {
        SwingUtilities.invokeLater(new Runnable() 
        {
            @Override
            public void run() 
            {
                new NewWindow(new Dimension(800, 600));
            }
        });
    }
} 