import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
//window that shows specific recipe
class RecipeButtonListener implements ActionListener 
{
    private final String recipeName;

    public RecipeButtonListener(String recipeName) 
    {
        this.recipeName = recipeName;
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        JFrame recipeFrame = new JFrame(recipeName);
        recipeFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        recipeFrame.setSize(400, 400);
        recipeFrame.setLocationRelativeTo(null);

        JTextArea recipeArea = new JTextArea();
        recipeArea.setEditable(false);

        //reading a file with recipes and choosing needed recipe for the window
        try 
        {
            BufferedReader reader = new BufferedReader(new FileReader("recipes.txt"));
            String line;
            boolean foundRecipe = false;
            boolean readingIngredients = false;
            boolean readingInstructions = false;

            while ((line = reader.readLine()) != null) 
            {
                if (line.startsWith("Recipe:")) 
                {
                    String recipeTitle = line.substring(8).trim();
                    if (recipeTitle.equals(recipeName))
                    {
                        foundRecipe = true;
                        readingIngredients = false;
                        readingInstructions = false;
                    } 
                    
                    else 
                    {
                        foundRecipe = false;
                    }
                } 
                
                else if (line.equals("Ingredients:"))
                {
                    readingIngredients = true;
                    readingInstructions = false;
                }
                
                else if (line.equals("Ingredients:")) 
                {
                    readingIngredients = false;
                    readingInstructions = true;
                    recipeArea.append("Instructions:\n");
                } 
                
                else if (foundRecipe) 
                {
                    if (readingIngredients && !line.isEmpty())
                    {
                        recipeArea.append("" + line + "\n");
                    } 
                    else if (readingInstructions && !line.isEmpty())
                    {
                        recipeArea.append(line + "\n");
                    }
                }
            }

            reader.close();
        } 
        catch (IOException ex) 
        {
            ex.printStackTrace();
        }

        JScrollPane scrollPane = new JScrollPane(recipeArea);
        recipeFrame.getContentPane().add(scrollPane, BorderLayout.CENTER);
        recipeFrame.pack();
        recipeFrame.setVisible(true);
    }
}